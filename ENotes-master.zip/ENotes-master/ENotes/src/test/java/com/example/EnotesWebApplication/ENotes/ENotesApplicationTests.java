package com.example.EnotesWebApplication.ENotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ENotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
